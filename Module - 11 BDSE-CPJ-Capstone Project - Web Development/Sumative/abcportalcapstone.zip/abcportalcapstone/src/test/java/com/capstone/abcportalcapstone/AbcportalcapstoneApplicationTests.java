package com.capstone.abcportalcapstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcportalcapstoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
