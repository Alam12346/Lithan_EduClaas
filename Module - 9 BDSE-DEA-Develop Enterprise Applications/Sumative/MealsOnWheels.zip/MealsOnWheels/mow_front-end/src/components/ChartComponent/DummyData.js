export const dummyData = [
  {
    mealsName: "baso",
    mealsGained: 200,
  },
  {
    mealsName: "sangu padang",
    mealsGained: 150,
  },
  {
    mealsName: "nasi goreng",
    mealsGained: 10,
  },
];
