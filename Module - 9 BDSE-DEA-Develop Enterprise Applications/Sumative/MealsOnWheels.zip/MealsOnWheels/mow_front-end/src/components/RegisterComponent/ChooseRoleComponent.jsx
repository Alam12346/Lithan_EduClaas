const ChooseRoleComponent = () => {
  return (
    <>
      <h1>sdfadsf</h1>
    </>
  );
};

export default ChooseRoleComponent;
