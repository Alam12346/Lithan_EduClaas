const RoleDetailsComponent = () => {
  return <></>;
};

export default RoleDetailsComponent;
