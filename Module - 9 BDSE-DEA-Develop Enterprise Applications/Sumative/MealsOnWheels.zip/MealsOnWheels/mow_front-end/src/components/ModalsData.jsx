const ModalsData = () => {
  return (
    <>
      <h1>sdfds</h1>
    </>
  );
};

export default ModalsData;
