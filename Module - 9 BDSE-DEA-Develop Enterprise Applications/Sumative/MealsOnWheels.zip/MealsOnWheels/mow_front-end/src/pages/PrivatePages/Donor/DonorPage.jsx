import { PayPalScriptProvider } from "@paypal/react-paypal-js";
import DonorForm from "./DonorForm";

const DonorPage = () => {
  return <DonorForm />;
};

export default DonorPage;
