package com.summative.mealsonwheels.Entity.constrant;

public enum OrderStatus {
    PENDING, ASSIGNED, PROCESS, ON_THE_WAY, DELIVERED, COMPLETED
}
