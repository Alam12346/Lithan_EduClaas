package com.summative.mealsonwheels.Dto.EntityRequest;

import lombok.Data;

@Data
public class OrderMealRequest {

    private Long mealId;
    private double distance;

}
