package com.summative.mealsonwheels.Entity.constrant;

public enum UserRole {
    MEMBER, DRIVER, PARTNER, ADMIN, VOLUNTEER, DONOR
}
