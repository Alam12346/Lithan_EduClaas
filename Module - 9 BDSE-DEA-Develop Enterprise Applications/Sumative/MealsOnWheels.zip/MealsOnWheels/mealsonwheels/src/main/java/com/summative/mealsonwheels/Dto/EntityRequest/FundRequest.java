package com.summative.mealsonwheels.Dto.EntityRequest;
import lombok.Data;

@Data
public class FundRequest {
    

    private double donorAmount;

}
